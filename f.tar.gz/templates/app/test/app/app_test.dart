import 'package:fluframe_app/app/app.dart';
import 'package:fluframe_app/app/router/route_not_found_screen.dart';
import 'package:fluframe_app/core/analytics/analytics_service.dart';
import 'package:fluframe_app/features/auth/presentation/login_screen.dart';
import 'package:fluframe_app/features/auth/presentation/profile_screen.dart';
import 'package:fluframe_app/features/home/presentation/home_screen.dart';
import 'package:fluframe_app/features/posts/data/posts_repository.dart';
import 'package:fluframe_app/features/posts/domain/post.dart';
import 'package:fluframe_app/features/posts/presentation/post_not_found_screen.dart';
import 'package:fluframe_app/features/settings/presentation/settings_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:go_router/go_router.dart';

import '../helpers/helpers.dart';

/// Answers from memory so a route test never reaches the network.
///
/// Navigating into `/home/posts/...` builds the posts list on the way to
/// the leaf, and the real repository starts a Dio request that no test
/// environment ever completes — leaving a pending timer that fails the
/// test at teardown.
class _OfflinePostsRepository implements PostsRepository {
  @override
  Future<List<Post>> fetchPosts({
    int page = 1,
    int limit = postsPageSize,
  }) async => const [];

  @override
  Future<Post> fetchPost(int id) async =>
      Post(id: id, userId: 1, title: 'Post $id', body: 'body $id');
}

void main() {
  group('AppRoot', () {
    testWidgets('boots to the home screen with bottom navigation', (
      tester,
    ) async {
      await tester.pumpWidget(
        ProviderScope(
          overrides: appTestOverrides(),
          child: const AppRoot(),
        ),
      );
      await tester.pumpAndSettle();

      expect(find.byType(HomeScreen), findsOneWidget);
      expect(find.byType(NavigationBar), findsOneWidget);
    });

    testWidgets('switches to the settings tab', (tester) async {
      await tester.pumpWidget(
        ProviderScope(
          overrides: appTestOverrides(),
          child: const AppRoot(),
        ),
      );
      await tester.pumpAndSettle();

      await tester.tap(find.byIcon(Icons.settings_outlined));
      await tester.pumpAndSettle();

      expect(find.byType(SettingsScreen), findsOneWidget);
    });

    testWidgets('navigation reports screen views', (tester) async {
      final analytics = RecordingAnalyticsService();
      await tester.pumpWidget(
        ProviderScope(
          overrides: [
            ...appTestOverrides(),
            analyticsServiceProvider.overrideWithValue(analytics),
          ],
          child: const AppRoot(),
        ),
      );
      await tester.pumpAndSettle();

      await tester.tap(find.byIcon(Icons.settings_outlined));
      await tester.pumpAndSettle();

      expect(analytics.screenViews, contains('/settings'));
    });

    testWidgets('screen views report the route pattern, not the path', (
      tester,
    ) async {
      // Regression: `/home/posts/42` was sent verbatim, which explodes
      // dashboard cardinality and would leak a value like /invite/:token
      // to a third-party service the moment such a route exists.
      final analytics = RecordingAnalyticsService();
      await tester.pumpWidget(
        ProviderScope(
          overrides: [
            ...appTestOverrides(),
            analyticsServiceProvider.overrideWithValue(analytics),
          ],
          child: const AppRoot(),
        ),
      );
      await tester.pumpAndSettle();

      final context = tester.element(find.byType(HomeScreen));
      GoRouter.of(context).go('/home/posts/42');
      await tester.pumpAndSettle();

      expect(analytics.screenViews, contains('/home/posts/:id'));
      expect(analytics.screenViews, isNot(contains('/home/posts/42')));
    });

    testWidgets('an unmatched deep link offers a way back', (tester) async {
      // Regression: go_router's default error page was reached instead,
      // and its only button navigates to `/`, which this app did not
      // define — leaving force-quit as the sole escape.
      await tester.pumpWidget(
        ProviderScope(
          overrides: appTestOverrides(),
          child: const AppRoot(),
        ),
      );
      await tester.pumpAndSettle();

      final context = tester.element(find.byType(HomeScreen));
      GoRouter.of(context).go('/nope/not/a/route');
      await tester.pumpAndSettle();

      expect(find.byType(RouteNotFoundScreen), findsOneWidget);

      await tester.tap(find.byType(FilledButton));
      await tester.pumpAndSettle();

      expect(find.byType(HomeScreen), findsOneWidget);
    });

    testWidgets('a post id that is not a number lands on the not-found '
        'screen', (tester) async {
      // /home/posts/:id is the app's only deep-linkable route, and its id
      // goes through int.tryParse. The sibling case — an unmatched route,
      // above — has had a regression test since it broke; this branch had
      // none, so nothing would have noticed it starting to throw.
      await tester.pumpWidget(
        ProviderScope(
          overrides: [
            ...appTestOverrides(),
            postsRepositoryProvider.overrideWithValue(
              _OfflinePostsRepository(),
            ),
          ],
          child: const AppRoot(),
        ),
      );
      await tester.pumpAndSettle();

      final context = tester.element(find.byType(HomeScreen));
      GoRouter.of(context).go('/home/posts/abc');
      await tester.pumpAndSettle();

      expect(find.byType(PostNotFoundScreen), findsOneWidget);
      expect(find.text('Post not found.'), findsOneWidget);
    });

    testWidgets('the root URL resolves to home', (tester) async {
      await tester.pumpWidget(
        ProviderScope(
          overrides: appTestOverrides(),
          child: const AppRoot(),
        ),
      );
      await tester.pumpAndSettle();

      final context = tester.element(find.byType(HomeScreen));
      GoRouter.of(context).go('/settings');
      await tester.pumpAndSettle();
      GoRouter.of(tester.element(find.byType(SettingsScreen))).go('/');
      await tester.pumpAndSettle();

      expect(find.byType(HomeScreen), findsOneWidget);
      expect(find.byType(RouteNotFoundScreen), findsNothing);
    });

    testWidgets('profile tab redirects to login while signed out', (
      tester,
    ) async {
      await tester.pumpWidget(
        ProviderScope(
          overrides: appTestOverrides(),
          child: const AppRoot(),
        ),
      );
      await tester.pumpAndSettle();

      await tester.tap(find.byIcon(Icons.person_outline));
      await tester.pumpAndSettle();

      expect(find.byType(LoginScreen), findsOneWidget);
    });

    testWidgets('signing in lands on profile; signing out returns to login', (
      tester,
    ) async {
      await tester.pumpWidget(
        ProviderScope(
          overrides: appTestOverrides(),
          child: const AppRoot(),
        ),
      );
      await tester.pumpAndSettle();

      await tester.tap(find.byIcon(Icons.person_outline));
      await tester.pumpAndSettle();
      await tester.enterText(
        find.byType(TextFormField).first,
        'dev@example.com',
      );
      await tester.enterText(find.byType(TextFormField).last, 'secret1');
      await tester.tap(find.widgetWithText(FilledButton, 'Sign in'));
      await tester.pumpAndSettle();

      expect(find.byType(ProfileScreen), findsOneWidget);
      expect(find.text('Signed in as dev@example.com'), findsOneWidget);

      await tester.tap(find.text('Sign out'));
      await tester.pumpAndSettle();

      expect(find.byType(LoginScreen), findsOneWidget);
    });
  });
}
